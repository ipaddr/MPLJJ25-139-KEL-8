import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:bantuancheck/utils/constants.dart';
import 'package:bantuancheck/pages/login_page.dart';
import 'package:bantuancheck/pages/register_page.dart';
import 'package:bantuancheck/pages/home_page.dart';
import 'package:bantuancheck/pages/pengajuan_page.dart';
import 'package:bantuancheck/pages/riwayat_page.dart';
import 'package:bantuancheck/pages/edukasi_page.dart';
// Import yang tidak dipakai telah dihapus:
// import 'package:bantuancheck/pages/admin/dashboard_admin_page.dart';
// import 'package:bantuancheck/pages/admin/statistik_page.dart';
// import 'package:bantuancheck/pages/admin/verifikasi_page.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const BantuanCheckApp());
}

class BantuanCheckApp extends StatelessWidget {
  const BantuanCheckApp({Key? key}) : super(key: key); // Tambahkan Key

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: kAppName,
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primaryColor: kPrimaryColor,
        scaffoldBackgroundColor: Colors.white,
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: kPrimaryColor,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
          ),
        ),
        textTheme: const TextTheme(
          titleLarge: TextStyle(
              fontSize: kTitleFontSize,
              fontWeight: FontWeight.bold,
              color: Colors.black),
          bodyMedium: TextStyle(fontSize: kBodyFontSize),
        ),
      ),
      initialRoute: kRouteLogin,
      routes: {
        kRouteLogin: (context) => const LoginPage(),
        kRouteRegister: (context) => const RegisterPage(),
        kRouteHome: (context) => const HomePage(),
        kRoutePengajuan: (context) => const PengajuanPage(),
        kRouteRiwayat: (context) => const RiwayatPage(),
        kRouteEdukasi: (context) => const EdukasiPage(),
      },
    );
  }
}
